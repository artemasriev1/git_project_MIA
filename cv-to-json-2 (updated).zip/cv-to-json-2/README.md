# cv-to-json

Extract structured data (contact, skills, experience, education) from raw CV text into a validated JSON document, using an LLM.

Course project: *Git as a reflex, prompt engineering as a craft*. One use case, built incrementally across six sessions; every session ends with a runnable commit.

## Quick start (from a clean machine)

```bash
git clone <repo-url> && cd cv-to-json
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                 # then paste your ANTHROPIC_API_KEY
python -m src.extract data/cvs/cv_01.txt             # one CV -> outputs/cv_01.json
python -m src.extract data/cvs/ --prompt few_shot    # whole folder
python -m src.evaluate                               # score outputs/ against data/ground_truth/
pytest                                               # unit tests (no API key needed)
```

No API key? `CV2JSON_MOCK=1 python -m src.extract data/cvs/` replays saved responses from `data/mock/` so the pipeline can be demoed offline. The shipped mock set is illustrative (built by `scripts/build_mock.py`); record real ones with `CV2JSON_RECORD=1` once you have a key.

## Repository layout

```
src/         Python package: API client (retry), extraction CLI, schema, evaluation
prompts/     One markdown file per prompt variant (system, zero_shot, few_shot, cot)
data/cvs/    Raw CVs as .txt (synthetic, no real people)
data/ground_truth/   Hand-written expected JSON, one per CV — the evaluation rubric
data/mock/   Saved model outputs for offline demo
outputs/     Generated JSON (git-ignored except .gitkeep)
notebooks/   Exploration only; nothing here is needed to run the project
docs/        Prompt log, failure modes, design decisions
tests/       pytest suite
```

## How it works

1. `src/extract.py` loads `prompts/system.md` + the chosen variant, sends the CV text to the Anthropic API.
2. `src/client.py` wraps the call with exponential-backoff retry on rate limits and 5xx.
3. The response is parsed and validated against `src/schema.py` (pydantic). Invalid JSON = extraction failure, recorded as such.
4. `src/evaluate.py` compares every output to its ground truth field by field and prints precision / recall / exact-match per field and per prompt variant.

## Output schema

```json
{
  "full_name": "string",
  "email": "string|null",
  "phone": "string|null",
  "location": "string|null",
  "years_of_experience": 0,
  "skills": ["string"],
  "experience": [{"company": "", "title": "", "start": "YYYY-MM|null", "end": "YYYY-MM|null|present", "highlights": [""]}],
  "education": [{"institution": "", "degree": "", "year": 0}],
  "languages": [{"language": "", "level": ""}],
  "confidence": 0.0,
  "missing_fields": ["string"]
}
```

`missing_fields` is the anti-hallucination lever: the model is told to list what it could not find rather than invent it.

## Session log

| Session | Commit | What runs |
|---|---|---|
| 1 | Skeleton, README, 6 synthetic CVs + ground truth | `pytest` (schema) |
| 2 | API client with retry, zero-shot extraction CLI | `python -m src.extract` |
| 3 | Branch `feat/few-shot`, PR, merge conflict on `prompts/system.md` | `--prompt few_shot` |
| 4 | Chain-of-thought variant, evaluation script, rubric | `python -m src.evaluate` |
| 5 | Failure-mode demos (hallucination, sycophancy, injection, context overflow) | `python -m src.failure_demo injection` |
| 6 | Results table, defence notes, exploration notebook | `docs/results.md`, `docs/defence_notes.md` |

## Results (summary)

Few-shot is the default prompt: it fixes inferred `years_of_experience` and resists the injected CV at no measurable cost. Chain-of-thought gives the same fixes but fails validation on the long CV. Full table and the honest caveat about mock data in `docs/results.md`.

## Docs

- `docs/prompt_log.md`: why each prompt version exists
- `docs/pr_001_few_shot.md`: the pull request, review comments, and the merge conflict
- `docs/failure_modes.md`: the four failure modes on this data, with mitigations and their cost
- `docs/defence_notes.md`: justification of every technical choice, for the oral
