"""cv-to-json: extract structured data from CV text with an LLM."""
