Extract the JSON for the following CV.

<cv>
{cv_text}
</cv>
